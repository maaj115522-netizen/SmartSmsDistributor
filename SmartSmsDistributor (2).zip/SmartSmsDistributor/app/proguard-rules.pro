# ProGuard rules for SmartSmsDistributor
-keepclassmembers class * {
    @androidx.room.Entity <fields>;
}
