package com.smartsms.distributor.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.smartsms.distributor.SmartSmsApp
import com.smartsms.distributor.data.db.BankSenderEntity
import com.smartsms.distributor.data.db.ForwardingRuleEntity
import com.smartsms.distributor.data.db.RecipientEntity
import com.smartsms.distributor.data.db.RuleWithDetails
import com.smartsms.distributor.data.db.TransferLogEntity
import com.smartsms.distributor.service.SmsForegroundService
import com.smartsms.distributor.util.InboxReader
import com.smartsms.distributor.util.InboxSenderItem
import com.smartsms.distributor.util.SimCardInfo
import com.smartsms.distributor.util.SimUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as SmartSmsApp
    private val db = app.database
    private val prefs = app.preferences

    val banks: StateFlow<List<BankSenderEntity>> = db.bankSenderDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val recipients: StateFlow<List<RecipientEntity>> = db.recipientDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val rules: StateFlow<List<RuleWithDetails>> = db.forwardingRuleDao().observeAllWithDetails()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val logs: StateFlow<List<TransferLogEntity>> = db.transferLogDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val isServiceEnabled: StateFlow<Boolean> = prefs.isServiceEnabled
    val selectedSimId: StateFlow<Int> = prefs.selectedSubscriptionId
    val globalIncludeKeywords: StateFlow<String> = prefs.globalIncludeKeywords
    val globalExcludeKeywords: StateFlow<String> = prefs.globalExcludeKeywords

    private val _inboxSenders = MutableStateFlow<List<InboxSenderItem>>(emptyList())
    val inboxSenders: StateFlow<List<InboxSenderItem>> = _inboxSenders.asStateFlow()

    private val _isLoadingInbox = MutableStateFlow(false)
    val isLoadingInbox: StateFlow<Boolean> = _isLoadingInbox.asStateFlow()

    private val _activeSims = MutableStateFlow<List<SimCardInfo>>(emptyList())
    val activeSims: StateFlow<List<SimCardInfo>> = _activeSims.asStateFlow()

    private val _isBatteryOptIgnored = MutableStateFlow(false)
    val isBatteryOptIgnored: StateFlow<Boolean> = _isBatteryOptIgnored.asStateFlow()

    private val _hasCorePermissions = MutableStateFlow(false)
    val hasCorePermissions: StateFlow<Boolean> = _hasCorePermissions.asStateFlow()

    init {
        refreshSystemStatus()
    }

    fun refreshSystemStatus() {
        _hasCorePermissions.value = SimUtils.hasAllCorePermissions(app)
        _isBatteryOptIgnored.value = SimUtils.isIgnoringBatteryOptimizations(app)
        _activeSims.value = SimUtils.getActiveSims(app)
    }

    fun toggleService(enabled: Boolean) {
        prefs.setServiceEnabled(enabled)
        if (enabled) {
            SmsForegroundService.start(app)
        } else {
            SmsForegroundService.stop(app)
        }
    }

    fun saveGlobalFilters(includeKeywords: String, excludeKeywords: String) {
        prefs.setGlobalFilters(includeKeywords.trim(), excludeKeywords.trim())
    }

    fun loadInboxSenders() {
        if (!SimUtils.hasPermission(app, android.Manifest.permission.READ_SMS)) {
            _inboxSenders.value = emptyList()
            return
        }
        viewModelScope.launch {
            _isLoadingInbox.value = true
            try {
                _inboxSenders.value = InboxReader.getUniqueSenders(app)
            } finally {
                _isLoadingInbox.value = false
            }
        }
    }

    fun addBankFromInbox(address: String, customName: String = "") {
        val cleanAddress = address.trim()
        if (cleanAddress.isBlank()) return
        val display = customName.trim().ifBlank { cleanAddress }
        viewModelScope.launch {
            db.bankSenderDao().insert(
                BankSenderEntity(
                    senderAddress = cleanAddress,
                    displayName = display,
                    isEnabled = true
                )
            )
        }
    }

    fun updateBankName(bank: BankSenderEntity, newDisplayName: String) {
        val display = newDisplayName.trim().ifBlank { bank.senderAddress }
        viewModelScope.launch {
            db.bankSenderDao().update(bank.copy(displayName = display))
        }
    }

    fun toggleBank(bank: BankSenderEntity, enabled: Boolean) {
        viewModelScope.launch {
            db.bankSenderDao().setEnabled(bank.id, enabled)
        }
    }

    fun deleteBank(bank: BankSenderEntity) {
        viewModelScope.launch {
            db.bankSenderDao().delete(bank)
        }
    }

    fun addRecipient(phoneNumber: String, label: String) {
        val cleanPhone = phoneNumber.trim()
        if (cleanPhone.isBlank()) return
        viewModelScope.launch {
            db.recipientDao().insert(
                RecipientEntity(
                    phoneNumber = cleanPhone,
                    label = label.trim(),
                    isEnabled = true
                )
            )
        }
    }

    fun updateRecipient(recipient: RecipientEntity, newPhone: String, newLabel: String) {
        val cleanPhone = newPhone.trim()
        if (cleanPhone.isBlank()) return
        viewModelScope.launch {
            db.recipientDao().update(
                recipient.copy(phoneNumber = cleanPhone, label = newLabel.trim())
            )
        }
    }

    fun toggleRecipient(recipient: RecipientEntity, enabled: Boolean) {
        viewModelScope.launch {
            db.recipientDao().setEnabled(recipient.id, enabled)
        }
    }

    fun deleteRecipient(recipient: RecipientEntity) {
        viewModelScope.launch {
            db.recipientDao().delete(recipient)
        }
    }

    fun saveRule(
        ruleId: Long = 0L,
        name: String,
        bankSenderId: Long,
        recipientIds: List<Long>,
        includeKeywords: String = "",
        excludeKeywords: String = "",
        isEnabled: Boolean = true
    ) {
        if (bankSenderId <= 0L || recipientIds.isEmpty()) return
        viewModelScope.launch {
            val cleanName = name.trim().ifBlank { "قاعدة توجيه" }
            db.forwardingRuleDao().saveRuleWithRecipients(
                rule = ForwardingRuleEntity(
                    id = ruleId,
                    name = cleanName,
                    bankSenderId = bankSenderId,
                    isEnabled = isEnabled,
                    includeKeywords = includeKeywords.trim(),
                    excludeKeywords = excludeKeywords.trim()
                ),
                recipientIds = recipientIds
            )
        }
    }

    fun updateRuleFilters(
        rule: ForwardingRuleEntity,
        includeKeywords: String,
        excludeKeywords: String
    ) {
        viewModelScope.launch {
            db.forwardingRuleDao().updateRule(
                rule.copy(
                    includeKeywords = includeKeywords.trim(),
                    excludeKeywords = excludeKeywords.trim()
                )
            )
        }
    }

    fun toggleRule(rule: ForwardingRuleEntity, enabled: Boolean) {
        viewModelScope.launch {
            db.forwardingRuleDao().setEnabled(rule.id, enabled)
        }
    }

    fun deleteRule(rule: ForwardingRuleEntity) {
        viewModelScope.launch {
            db.forwardingRuleDao().deleteRule(rule)
        }
    }

    fun clearLogs() {
        viewModelScope.launch {
            db.transferLogDao().clearAll()
        }
    }

    fun selectSim(subscriptionId: Int) {
        prefs.setSelectedSubscriptionId(subscriptionId)
    }
}
