package com.smartsms.distributor.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import com.smartsms.distributor.SmartSmsApp
import com.smartsms.distributor.data.db.RecipientEntity
import com.smartsms.distributor.data.db.TransferLogEntity
import com.smartsms.distributor.data.db.TransferStatus
import com.smartsms.distributor.util.SmsHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        val app = context.applicationContext as? SmartSmsApp ?: return
        if (!app.preferences.isServiceEnabledSync()) return

        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        if (messages.isNullOrEmpty()) return

        // تجميع أجزاء الرسالة الواردة لكل مرسل لضمان اكتمال النص العربي الطويل
        val groupedBySender = linkedMapOf<String, Pair<Long, StringBuilder>>()
        for (sms in messages) {
            val sender = sms.originatingAddress?.trim().orEmpty()
            if (sender.isBlank()) continue
            val bodyPart = sms.messageBody.orEmpty()
            val timestamp = sms.timestampMillis

            val entry = groupedBySender[sender]
            if (entry == null) {
                groupedBySender[sender] = timestamp to StringBuilder(bodyPart)
            } else {
                entry.second.append(bodyPart)
            }
        }

        if (groupedBySender.isEmpty()) return

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = app.database
                val bankDao = db.bankSenderDao()
                val ruleDao = db.forwardingRuleDao()
                val logDao = db.transferLogDao()

                val enabledBanks = bankDao.getEnabledSenders()
                if (enabledBanks.isEmpty()) return@launch

                val selectedSubId = app.preferences.getSelectedSubscriptionIdSync()
                val globalInclude = app.preferences.getGlobalIncludeKeywordsSync()
                val globalExclude = app.preferences.getGlobalExcludeKeywordsSync()

                for ((senderAddress, timestampAndBody) in groupedBySender) {
                    val timestampMillis = timestampAndBody.first
                    val fullBody = timestampAndBody.second.toString()
                    if (fullBody.isEmpty()) continue

                    // التحقق من التصفية العامة على مستوى التطبيق
                    if (!SmsHelper.matchesFilter(fullBody, globalInclude, globalExclude)) {
                        continue
                    }

                    val matchedBanks = enabledBanks.filter {
                        SmsHelper.senderMatches(senderAddress, it.senderAddress)
                    }
                    if (matchedBanks.isEmpty()) continue

                    val uniqueRecipients = linkedMapOf<String, RecipientEntity>()
                    var primaryBankDisplayName = matchedBanks.first().displayName

                    for (bank in matchedBanks) {
                        val activeRules = ruleDao.getEnabledRulesForBank(bank.id)
                        for (ruleDetail in activeRules) {
                            // التحقق من تصفية الكلمات الخاصة بهذه القاعدة
                            val passesRuleFilter = SmsHelper.matchesFilter(
                                messageBody = fullBody,
                                includeRaw = ruleDetail.rule.includeKeywords,
                                excludeRaw = ruleDetail.rule.excludeKeywords
                            )
                            if (!passesRuleFilter) continue

                            primaryBankDisplayName = bank.displayName
                            for (recipient in ruleDetail.recipients) {
                                if (recipient.isEnabled) {
                                    uniqueRecipients.putIfAbsent(recipient.phoneNumber, recipient)
                                }
                            }
                        }
                    }

                    if (uniqueRecipients.isEmpty()) continue

                    val messageKey = SmsHelper.buildMessageKey(
                        sender = senderAddress,
                        timestampMillis = timestampMillis,
                        body = fullBody
                    )

                    for (recipient in uniqueRecipients.values) {
                        // منع التكرار لنفس الرسالة ونفس المستلم (Idempotency)
                        if (logDao.existsByKeyAndRecipient(messageKey, recipient.phoneNumber)) {
                            continue
                        }

                        val parts = SmsHelper.divideMessage(context, selectedSubId, fullBody)
                        val logId = logDao.insert(
                            TransferLogEntity(
                                messageKey = messageKey,
                                senderAddress = senderAddress,
                                senderDisplayName = primaryBankDisplayName,
                                recipientNumber = recipient.phoneNumber,
                                recipientLabel = recipient.label,
                                messageBody = fullBody,
                                receivedAt = System.currentTimeMillis(),
                                status = TransferStatus.PENDING,
                                totalParts = parts.size
                            )
                        )

                        if (logId > 0L) {
                            try {
                                SmsHelper.sendMultipartSms(
                                    context = context,
                                    subscriptionId = selectedSubId,
                                    destinationAddress = recipient.phoneNumber,
                                    parts = parts,
                                    logId = logId
                                )
                            } catch (e: Exception) {
                                logDao.markFailed(
                                    id = logId,
                                    errorMessage = e.localizedMessage ?: "فشل إرسال الرسالة"
                                )
                            }
                        }
                    }
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
