package com.smartsms.distributor.util

import android.content.Context
import android.provider.Telephony
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class InboxSenderItem(
    val address: String,
    val latestBody: String,
    val latestDate: Long,
    val messageCount: Int
)

object InboxReader {
    suspend fun getUniqueSenders(context: Context): List<InboxSenderItem> = withContext(Dispatchers.IO) {
        val senderMap = linkedMapOf<String, InboxSenderItem>()
        val projection = arrayOf(
            Telephony.Sms.ADDRESS,
            Telephony.Sms.BODY,
            Telephony.Sms.DATE
        )

        context.contentResolver.query(
            Telephony.Sms.Inbox.CONTENT_URI,
            projection,
            null,
            null,
            "${Telephony.Sms.DATE} DESC"
        )?.use { cursor ->
            val addressIdx = cursor.getColumnIndex(Telephony.Sms.ADDRESS)
            val bodyIdx = cursor.getColumnIndex(Telephony.Sms.BODY)
            val dateIdx = cursor.getColumnIndex(Telephony.Sms.DATE)

            while (cursor.moveToNext()) {
                val rawAddress = if (addressIdx >= 0) cursor.getString(addressIdx)?.trim() else null
                if (rawAddress.isNullOrBlank()) continue

                val key = rawAddress.lowercase()
                val body = if (bodyIdx >= 0) cursor.getString(bodyIdx).orEmpty() else ""
                val date = if (dateIdx >= 0) cursor.getLong(dateIdx) else 0L

                val existing = senderMap[key]
                if (existing == null) {
                    senderMap[key] = InboxSenderItem(
                        address = rawAddress,
                        latestBody = body,
                        latestDate = date,
                        messageCount = 1
                    )
                } else {
                    senderMap[key] = existing.copy(messageCount = existing.messageCount + 1)
                }
            }
        }

        senderMap.values.toList()
    }
}
