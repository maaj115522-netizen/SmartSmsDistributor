package com.smartsms.distributor.receiver

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.SmsManager
import com.smartsms.distributor.SmartSmsApp
import com.smartsms.distributor.util.SmsHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SmsStatusReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val logId = intent.getLongExtra(SmsHelper.EXTRA_LOG_ID, -1L)
        if (logId <= 0L) return

        val app = context.applicationContext as? SmartSmsApp ?: return
        val resultCode = resultCode
        val action = intent.action

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val logDao = app.database.transferLogDao()
                when (action) {
                    SmsHelper.ACTION_SMS_SENT -> {
                        if (resultCode == Activity.RESULT_OK) {
                            logDao.markPartSent(logId)
                        } else {
                            logDao.markFailed(logId, mapSendError(resultCode))
                        }
                    }
                    SmsHelper.ACTION_SMS_DELIVERED -> {
                        if (resultCode == Activity.RESULT_OK) {
                            logDao.markPartDelivered(logId)
                        } else {
                            logDao.markFailed(logId, "فشل تأكيد التسليم (رمز: $resultCode)")
                        }
                    }
                }
            } finally {
                pendingResult.finish()
            }
        }
    }

    private fun mapSendError(resultCode: Int): String {
        return when (resultCode) {
            SmsManager.RESULT_ERROR_GENERIC_FAILURE -> "فشل عام في الشبكة أو الشريحة"
            SmsManager.RESULT_ERROR_NO_SERVICE -> "لا توجد تغطية شبكة"
            SmsManager.RESULT_ERROR_NULL_PDU -> "خطأ في حزمة البيانات (PDU)"
            SmsManager.RESULT_ERROR_RADIO_OFF -> "وضع الطيران مفعّل أو الشبكة مغلقة"
            else -> "فشل الإرسال (رمز: $resultCode)"
        }
    }
}
