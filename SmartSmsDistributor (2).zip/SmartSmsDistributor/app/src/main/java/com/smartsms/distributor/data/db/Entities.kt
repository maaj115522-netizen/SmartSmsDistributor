package com.smartsms.distributor.data.db

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.Junction
import androidx.room.PrimaryKey
import androidx.room.Relation

@Entity(
    tableName = "bank_senders",
    indices = [Index(value = ["senderAddress"], unique = true)]
)
data class BankSenderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val senderAddress: String,
    val displayName: String,
    val isEnabled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "recipients",
    indices = [Index(value = ["phoneNumber"], unique = true)]
)
data class RecipientEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val phoneNumber: String,
    val label: String = "",
    val isEnabled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "forwarding_rules",
    foreignKeys = [
        ForeignKey(
            entity = BankSenderEntity::class,
            parentColumns = ["id"],
            childColumns = ["bankSenderId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["bankSenderId"])]
)
data class ForwardingRuleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val bankSenderId: Long,
    val isEnabled: Boolean = true,
    val includeKeywords: String = "",
    val excludeKeywords: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "rule_recipient_cross_ref",
    primaryKeys = ["ruleId", "recipientId"],
    foreignKeys = [
        ForeignKey(
            entity = ForwardingRuleEntity::class,
            parentColumns = ["id"],
            childColumns = ["ruleId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = RecipientEntity::class,
            parentColumns = ["id"],
            childColumns = ["recipientId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["recipientId"])]
)
data class RuleRecipientCrossRef(
    val ruleId: Long,
    val recipientId: Long
)

data class RuleWithDetails(
    @Embedded val rule: ForwardingRuleEntity,
    @Relation(
        parentColumn = "bankSenderId",
        entityColumn = "id"
    )
    val bankSender: BankSenderEntity,
    @Relation(
        parentColumn = "id",
        entityColumn = "id",
        associateBy = Junction(
            value = RuleRecipientCrossRef::class,
            parentColumn = "ruleId",
            entityColumn = "recipientId"
        )
    )
    val recipients: List<RecipientEntity>
)

enum class TransferStatus {
    PENDING,
    SENT,
    DELIVERED,
    FAILED
}

@Entity(
    tableName = "transfer_logs",
    indices = [Index(value = ["messageKey", "recipientNumber"], unique = true)]
)
data class TransferLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val messageKey: String,
    val senderAddress: String,
    val senderDisplayName: String,
    val recipientNumber: String,
    val recipientLabel: String,
    val messageBody: String,
    val receivedAt: Long = System.currentTimeMillis(),
    val status: TransferStatus = TransferStatus.PENDING,
    val errorMessage: String? = null,
    val totalParts: Int = 1,
    val sentParts: Int = 0,
    val deliveredParts: Int = 0
)
