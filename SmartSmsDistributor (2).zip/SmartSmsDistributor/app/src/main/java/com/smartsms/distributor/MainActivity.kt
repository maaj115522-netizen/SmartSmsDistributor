package com.smartsms.distributor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AltRoute
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.smartsms.distributor.ui.MainViewModel
import com.smartsms.distributor.ui.screens.BanksScreen
import com.smartsms.distributor.ui.screens.LogsScreen
import com.smartsms.distributor.ui.screens.RecipientsScreen
import com.smartsms.distributor.ui.screens.RulesScreen
import com.smartsms.distributor.ui.screens.SettingsScreen
import com.smartsms.distributor.ui.theme.SmartSmsTheme
import com.smartsms.distributor.util.SimUtils

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SmartSmsTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    SmartSmsMainScreen(viewModel = viewModel)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshSystemStatus()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SmartSmsMainScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }

    val banks by viewModel.banks.collectAsStateWithLifecycle()
    val recipients by viewModel.recipients.collectAsStateWithLifecycle()
    val rules by viewModel.rules.collectAsStateWithLifecycle()
    val logs by viewModel.logs.collectAsStateWithLifecycle()
    val isServiceEnabled by viewModel.isServiceEnabled.collectAsStateWithLifecycle()
    val selectedSimId by viewModel.selectedSimId.collectAsStateWithLifecycle()
    val globalIncludeKeywords by viewModel.globalIncludeKeywords.collectAsStateWithLifecycle()
    val globalExcludeKeywords by viewModel.globalExcludeKeywords.collectAsStateWithLifecycle()
    val inboxSenders by viewModel.inboxSenders.collectAsStateWithLifecycle()
    val isLoadingInbox by viewModel.isLoadingInbox.collectAsStateWithLifecycle()
    val activeSims by viewModel.activeSims.collectAsStateWithLifecycle()
    val isBatteryOptIgnored by viewModel.isBatteryOptIgnored.collectAsStateWithLifecycle()
    val hasCorePermissions by viewModel.hasCorePermissions.collectAsStateWithLifecycle()

    val permissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        viewModel.refreshSystemStatus()
    }

    LaunchedEffect(Unit) {
        if (!SimUtils.hasAllCorePermissions(context)) {
            permissionsLauncher.launch(SimUtils.requiredPermissions())
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "الموزع الذكي للرسائل SMS",
                        fontWeight = FontWeight.Bold
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.AccountBalance, contentDescription = null) },
                    label = { Text("البنوك") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.People, contentDescription = null) },
                    label = { Text("المستلمون") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.AltRoute, contentDescription = null) },
                    label = { Text("القواعد") }
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Default.History, contentDescription = null) },
                    label = { Text("السجل") }
                )
                NavigationBarItem(
                    selected = selectedTab == 4,
                    onClick = { selectedTab = 4 },
                    icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                    label = { Text("الإعدادات") }
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isServiceEnabled) {
                        MaterialTheme.colorScheme.primaryContainer
                    } else {
                        MaterialTheme.colorScheme.surfaceVariant
                    }
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PowerSettingsNew,
                            contentDescription = null,
                            tint = if (isServiceEnabled) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                MaterialTheme.colorScheme.onSurfaceVariant
                            }
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = if (isServiceEnabled) "خدمة التوزيع مفعّلة" else "خدمة التوزيع متوقفة",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isServiceEnabled) {
                                    "تتم مراقبة رسائل البنوك وتوجيهها تلقائياً"
                                } else {
                                    "فعّل الزر لبدء التوزيع التلقائي للرسائل"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Switch(
                        checked = isServiceEnabled,
                        onCheckedChange = { enabled ->
                            if (enabled && !SimUtils.hasAllCorePermissions(context)) {
                                permissionsLauncher.launch(SimUtils.requiredPermissions())
                            }
                            viewModel.toggleService(enabled)
                        }
                    )
                }
            }

            Box(modifier = Modifier.weight(1f)) {
                when (selectedTab) {
                    0 -> BanksScreen(
                        banks = banks,
                        inboxSenders = inboxSenders,
                        isLoadingInbox = isLoadingInbox,
                        onOpenInboxPicker = {
                            if (SimUtils.hasPermission(context, android.Manifest.permission.READ_SMS)) {
                                viewModel.loadInboxSenders()
                            } else {
                                permissionsLauncher.launch(SimUtils.requiredPermissions())
                            }
                        },
                        onAddBankFromInbox = viewModel::addBankFromInbox,
                        onUpdateBankName = viewModel::updateBankName,
                        onToggleBank = viewModel::toggleBank,
                        onDeleteBank = viewModel::deleteBank
                    )
                    1 -> RecipientsScreen(
                        recipients = recipients,
                        onAddRecipient = viewModel::addRecipient,
                        onUpdateRecipient = viewModel::updateRecipient,
                        onToggleRecipient = viewModel::toggleRecipient,
                        onDeleteRecipient = viewModel::deleteRecipient
                    )
                    2 -> RulesScreen(
                        rules = rules,
                        banks = banks,
                        recipients = recipients,
                        globalIncludeKeywords = globalIncludeKeywords,
                        globalExcludeKeywords = globalExcludeKeywords,
                        onSaveGlobalFilters = viewModel::saveGlobalFilters,
                        onSaveRule = viewModel::saveRule,
                        onUpdateRuleFilters = viewModel::updateRuleFilters,
                        onToggleRule = viewModel::toggleRule,
                        onDeleteRule = viewModel::deleteRule
                    )
                    3 -> LogsScreen(
                        logs = logs,
                        onClearLogs = viewModel::clearLogs
                    )
                    4 -> SettingsScreen(
                        activeSims = activeSims,
                        selectedSimId = selectedSimId,
                        isBatteryOptIgnored = isBatteryOptIgnored,
                        hasCorePermissions = hasCorePermissions,
                        onSelectSim = viewModel::selectSim,
                        onRequestBatteryOptimization = {
                            context.startActivity(SimUtils.buildBatteryOptimizationIntent(context))
                        },
                        onRequestPermissions = {
                            permissionsLauncher.launch(SimUtils.requiredPermissions())
                        }
                    )
                }
            }
        }
    }
}
