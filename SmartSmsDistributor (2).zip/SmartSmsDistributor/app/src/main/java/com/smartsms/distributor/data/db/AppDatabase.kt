package com.smartsms.distributor.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

class DbConverters {
    @TypeConverter
    fun fromStatus(status: TransferStatus): String = status.name

    @TypeConverter
    fun toStatus(value: String): TransferStatus =
        runCatching { TransferStatus.valueOf(value) }.getOrDefault(TransferStatus.PENDING)
}

@Database(
    entities = [
        BankSenderEntity::class,
        RecipientEntity::class,
        ForwardingRuleEntity::class,
        RuleRecipientCrossRef::class,
        TransferLogEntity::class
    ],
    version = 2,
    exportSchema = false
)
@TypeConverters(DbConverters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun bankSenderDao(): BankSenderDao
    abstract fun recipientDao(): RecipientDao
    abstract fun forwardingRuleDao(): ForwardingRuleDao
    abstract fun transferLogDao(): TransferLogDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "ALTER TABLE forwarding_rules ADD COLUMN includeKeywords TEXT NOT NULL DEFAULT ''"
                )
                db.execSQL(
                    "ALTER TABLE forwarding_rules ADD COLUMN excludeKeywords TEXT NOT NULL DEFAULT ''"
                )
            }
        }

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "smart_sms_distributor.db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
