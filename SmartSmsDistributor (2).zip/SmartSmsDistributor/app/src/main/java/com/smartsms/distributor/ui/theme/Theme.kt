package com.smartsms.distributor.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFF0B6E4F),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD0F0E3),
    onPrimaryContainer = Color(0xFF042B1E),
    secondary = Color(0xFF1D4E89),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD6E4F5),
    onSecondaryContainer = Color(0xFF0B2340),
    tertiary = Color(0xFFB45309),
    background = Color(0xFFF6F8F7),
    onBackground = Color(0xFF111827),
    surface = Color.White,
    onSurface = Color(0xFF111827),
    surfaceVariant = Color(0xFFE7ECEA),
    onSurfaceVariant = Color(0xFF4B5563),
    error = Color(0xFFB91C1C),
    onError = Color.White
)

@Composable
fun SmartSmsTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColors,
        content = content
    )
}
