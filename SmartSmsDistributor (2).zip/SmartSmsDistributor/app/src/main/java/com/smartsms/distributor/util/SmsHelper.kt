package com.smartsms.distributor.util

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.telephony.SmsManager
import com.smartsms.distributor.data.prefs.AppPreferences
import com.smartsms.distributor.receiver.SmsStatusReceiver
import java.security.MessageDigest

object SmsHelper {
    const val ACTION_SMS_SENT = "com.smartsms.distributor.SMS_SENT"
    const val ACTION_SMS_DELIVERED = "com.smartsms.distributor.SMS_DELIVERED"
    const val EXTRA_LOG_ID = "extra_log_id"
    const val EXTRA_PART_INDEX = "extra_part_index"

    private val ARABIC_DIACRITICS_REGEX = Regex("[\\u064B-\\u065F\\u0670]")

    fun normalizeArabicForMatch(text: String): String {
        return text
            .replace(ARABIC_DIACRITICS_REGEX, "")
            .replace('أ', 'ا')
            .replace('إ', 'ا')
            .replace('آ', 'ا')
            .replace('ى', 'ي')
            .lowercase()
            .trim()
    }

    fun parseKeywords(raw: String): List<String> {
        return raw.split(",", "،", "\n")
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .distinct()
    }

    fun matchesFilter(
        messageBody: String,
        includeRaw: String,
        excludeRaw: String
    ): Boolean {
        val normalizedBody = normalizeArabicForMatch(messageBody)

        val excludes = parseKeywords(excludeRaw)
        if (excludes.any { normalizedBody.contains(normalizeArabicForMatch(it)) }) {
            return false
        }

        val includes = parseKeywords(includeRaw)
        if (includes.isNotEmpty()) {
            return includes.any { normalizedBody.contains(normalizeArabicForMatch(it)) }
        }

        return true
    }

    fun buildMessageKey(sender: String, timestampMillis: Long, body: String): String {
        val input = "${sender.trim().lowercase()}|$timestampMillis|$body"
        val digest = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    fun senderMatches(incoming: String, registered: String): Boolean {
        val a = incoming.trim()
        val b = registered.trim()
        if (a.equals(b, ignoreCase = true)) return true

        val digitsA = a.filter { it.isDigit() }
        val digitsB = b.filter { it.isDigit() }
        if (digitsA.length >= 7 && digitsB.length >= 7 &&
            a.none { it.isLetter() } && b.none { it.isLetter() }
        ) {
            return digitsA == digitsB ||
                digitsA.endsWith(digitsB.takeLast(9)) && digitsB.length >= 9 ||
                digitsB.endsWith(digitsA.takeLast(9)) && digitsA.length >= 9
        }
        return false
    }

    @Suppress("DEPRECATION")
    fun getSmsManager(context: Context, subscriptionId: Int): SmsManager {
        return if (subscriptionId != AppPreferences.DEFAULT_SIM_ID && subscriptionId > 0) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                context.getSystemService(SmsManager::class.java)
                    .createForSubscriptionId(subscriptionId)
            } else {
                SmsManager.getSmsManagerForSubscriptionId(subscriptionId)
            }
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                context.getSystemService(SmsManager::class.java)
            } else {
                SmsManager.getDefault()
            }
        }
    }

    fun divideMessage(context: Context, subscriptionId: Int, body: String): ArrayList<String> {
        val smsManager = getSmsManager(context, subscriptionId)
        val parts = smsManager.divideMessage(body)
        return if (parts.isEmpty()) arrayListOf(body) else parts
    }

    fun sendMultipartSms(
        context: Context,
        subscriptionId: Int,
        destinationAddress: String,
        parts: ArrayList<String>,
        logId: Long
    ) {
        val smsManager = getSmsManager(context, subscriptionId)
        val sentIntents = ArrayList<PendingIntent>(parts.size)
        val deliveryIntents = ArrayList<PendingIntent>(parts.size)

        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

        for (index in parts.indices) {
            val reqBase = ((logId and 0xFFFFFFL) * 100L + index).toInt()

            val sentIntent = Intent(context, SmsStatusReceiver::class.java).apply {
                action = ACTION_SMS_SENT
                putExtra(EXTRA_LOG_ID, logId)
                putExtra(EXTRA_PART_INDEX, index)
            }
            sentIntents.add(PendingIntent.getBroadcast(context, reqBase, sentIntent, flags))

            val deliveredIntent = Intent(context, SmsStatusReceiver::class.java).apply {
                action = ACTION_SMS_DELIVERED
                putExtra(EXTRA_LOG_ID, logId)
                putExtra(EXTRA_PART_INDEX, index)
            }
            deliveryIntents.add(PendingIntent.getBroadcast(context, reqBase + 50, deliveredIntent, flags))
        }

        smsManager.sendMultipartTextMessage(
            destinationAddress,
            null,
            parts,
            sentIntents,
            deliveryIntents
        )
    }
}
