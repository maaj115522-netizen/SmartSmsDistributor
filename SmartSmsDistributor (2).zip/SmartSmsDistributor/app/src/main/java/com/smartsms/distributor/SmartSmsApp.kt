package com.smartsms.distributor

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.smartsms.distributor.data.db.AppDatabase
import com.smartsms.distributor.data.prefs.AppPreferences

class SmartSmsApp : Application() {
    lateinit var database: AppDatabase
        private set

    lateinit var preferences: AppPreferences
        private set

    override fun onCreate() {
        super.onCreate()
        database = AppDatabase.getInstance(this)
        preferences = AppPreferences(this)
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_SERVICE_ID,
                "خدمة الموزع الذكي للرسائل",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "إشعار استمرار عمل خدمة توزيع الرسائل البنكية في الخلفية"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    companion object {
        const val CHANNEL_SERVICE_ID = "smart_sms_service_channel"
    }
}
