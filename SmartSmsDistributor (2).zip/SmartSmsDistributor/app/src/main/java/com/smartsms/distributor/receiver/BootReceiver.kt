package com.smartsms.distributor.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.smartsms.distributor.SmartSmsApp
import com.smartsms.distributor.service.SmsForegroundService

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action == Intent.ACTION_BOOT_COMPLETED || action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            val app = context.applicationContext as? SmartSmsApp ?: return
            if (app.preferences.isServiceEnabledSync()) {
                SmsForegroundService.start(context)
            }
        }
    }
}
