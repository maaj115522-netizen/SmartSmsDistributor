package com.smartsms.distributor.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AltRoute
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.InputChip
import androidx.compose.material3.InputChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.smartsms.distributor.data.db.BankSenderEntity
import com.smartsms.distributor.data.db.ForwardingRuleEntity
import com.smartsms.distributor.data.db.RecipientEntity
import com.smartsms.distributor.data.db.RuleWithDetails
import com.smartsms.distributor.util.SmsHelper

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun RulesScreen(
    rules: List<RuleWithDetails>,
    banks: List<BankSenderEntity>,
    recipients: List<RecipientEntity>,
    globalIncludeKeywords: String,
    globalExcludeKeywords: String,
    onSaveGlobalFilters: (includeKeywords: String, excludeKeywords: String) -> Unit,
    onSaveRule: (
        ruleId: Long,
        name: String,
        bankId: Long,
        recipientIds: List<Long>,
        includeKeywords: String,
        excludeKeywords: String,
        isEnabled: Boolean
    ) -> Unit,
    onUpdateRuleFilters: (ForwardingRuleEntity, String, String) -> Unit,
    onToggleRule: (ForwardingRuleEntity, Boolean) -> Unit,
    onDeleteRule: (ForwardingRuleEntity) -> Unit
) {
    var showRuleDialog by remember { mutableStateOf(false) }
    var editingRule by remember { mutableStateOf<RuleWithDetails?>(null) }
    var filteringRule by remember { mutableStateOf<RuleWithDetails?>(null) }
    var showGlobalFilterDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = {
                    editingRule = null
                    showRuleDialog = true
                },
                enabled = banks.isNotEmpty() && recipients.isNotEmpty(),
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(vertical = 12.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "إضافة قاعدة",
                    fontWeight = FontWeight.Bold
                )
            }

            OutlinedButton(
                onClick = { showGlobalFilterDialog = true },
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp)
            ) {
                Icon(Icons.Default.FilterAlt, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "تصفية عامة",
                    fontWeight = FontWeight.Bold
                )
            }
        }

        val globalIncCount = SmsHelper.parseKeywords(globalIncludeKeywords).size
        val globalExcCount = SmsHelper.parseKeywords(globalExcludeKeywords).size
        if (globalIncCount > 0 || globalExcCount > 0) {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "التصفية العامة نشطة: ($globalIncCount إرسال / $globalExcCount استبعاد)",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.primary
            )
        }

        if (banks.isEmpty() || recipients.isEmpty()) {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "أضف بنكاً واحداً ورقم مستلم واحد على الأقل لإنشاء قاعدة توجيه.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (rules.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.AltRoute,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    Text(
                        text = "لا توجد قواعد توجيه بعد",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(rules, key = { it.rule.id }) { item ->
                    val incList = SmsHelper.parseKeywords(item.rule.includeKeywords)
                    val excList = SmsHelper.parseKeywords(item.rule.excludeKeywords)

                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = item.rule.name,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "البنك: ${item.bankSender.displayName}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                IconButton(onClick = { filteringRule = item }) {
                                    Icon(
                                        Icons.Default.FilterAlt,
                                        contentDescription = "تصفية الكلمات",
                                        tint = if (incList.isNotEmpty() || excList.isNotEmpty()) {
                                            MaterialTheme.colorScheme.primary
                                        } else {
                                            MaterialTheme.colorScheme.onSurfaceVariant
                                        }
                                    )
                                }
                                IconButton(onClick = {
                                    editingRule = item
                                    showRuleDialog = true
                                }) {
                                    Icon(Icons.Default.Edit, contentDescription = "تعديل القاعدة")
                                }
                                IconButton(onClick = { onDeleteRule(item.rule) }) {
                                    Icon(
                                        Icons.Default.Delete,
                                        contentDescription = "حذف القاعدة",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                                Switch(
                                    checked = item.rule.isEnabled,
                                    onCheckedChange = { onToggleRule(item.rule, it) }
                                )
                            }

                            if (incList.isNotEmpty() || excList.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                if (incList.isNotEmpty()) {
                                    Text(
                                        text = "تُرسل عند وجود: ${incList.joinToString(" ، ")}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF065F46)
                                    )
                                }
                                if (excList.isNotEmpty()) {
                                    Text(
                                        text = "تُمنع عند وجود: ${excList.joinToString(" ، ")}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF991B1B)
                                    )
                                }
                            }

                            if (item.recipients.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "المستلمون المرتبطون (${item.recipients.size}):",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    item.recipients.forEach { rec ->
                                        AssistChip(
                                            onClick = {},
                                            label = {
                                                Text(
                                                    if (rec.label.isNotBlank()) "${rec.label} (${rec.phoneNumber})"
                                                    else rec.phoneNumber
                                                )
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // نافذة التصفية العامة
    if (showGlobalFilterDialog) {
        KeywordFilterDialog(
            title = "نافذة التصفية العامة (لكل البنوك)",
            subtitle = "تُطبق هذه الفلاتر على جميع الرسائل الواردة قبل قواعد البنوك.",
            initialInclude = globalIncludeKeywords,
            initialExclude = globalExcludeKeywords,
            onDismiss = { showGlobalFilterDialog = false },
            onSave = { inc, exc ->
                onSaveGlobalFilters(inc, exc)
                showGlobalFilterDialog = false
            }
        )
    }

    // نافذة تصفية قاعدة محددة
    filteringRule?.let { item ->
        KeywordFilterDialog(
            title = "تصفية رسائل: ${item.rule.name}",
            subtitle = "حدد الكلمات التي تسمح بالإرسال أو تمنعه لهذه القاعدة.",
            initialInclude = item.rule.includeKeywords,
            initialExclude = item.rule.excludeKeywords,
            onDismiss = { filteringRule = null },
            onSave = { inc, exc ->
                onUpdateRuleFilters(item.rule, inc, exc)
                filteringRule = null
            }
        )
    }

    // نافذة إضافة / تعديل القاعدة
    if (showRuleDialog) {
        val currentRule = editingRule
        var ruleName by remember { mutableStateOf(currentRule?.rule?.name.orEmpty()) }
        var selectedBank by remember {
            mutableStateOf(currentRule?.bankSender ?: banks.firstOrNull())
        }
        var bankMenuExpanded by remember { mutableStateOf(false) }
        val selectedRecipientIds = remember {
            mutableStateListOf<Long>().apply {
                currentRule?.recipients?.forEach { add(it.id) }
            }
        }
        var includeKeywords by remember { mutableStateOf(currentRule?.rule?.includeKeywords.orEmpty()) }
        var excludeKeywords by remember { mutableStateOf(currentRule?.rule?.excludeKeywords.orEmpty()) }
        var showInnerFilterDialog by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showRuleDialog = false },
            title = {
                Text(if (currentRule == null) "إضافة قاعدة توجيه" else "تعديل قاعدة التوجيه")
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 450.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    OutlinedTextField(
                        value = ruleName,
                        onValueChange = { ruleName = it },
                        label = { Text("اسم القاعدة (اختياري)") },
                        placeholder = { Text("مثال: تحويل إشعارات الإيداع") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    ExposedDropdownMenuBox(
                        expanded = bankMenuExpanded,
                        onExpandedChange = { bankMenuExpanded = !bankMenuExpanded }
                    ) {
                        OutlinedTextField(
                            value = selectedBank?.displayName ?: "اختر البنك",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("البنك (المرسل)") },
                            trailingIcon = {
                                ExposedDropdownMenuDefaults.TrailingIcon(expanded = bankMenuExpanded)
                            },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth()
                        )
                        ExposedDropdownMenu(
                            expanded = bankMenuExpanded,
                            onDismissRequest = { bankMenuExpanded = false }
                        ) {
                            banks.forEach { bank ->
                                DropdownMenuItem(
                                    text = { Text("${bank.displayName} (${bank.senderAddress})") },
                                    onClick = {
                                        selectedBank = bank
                                        bankMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedButton(
                        onClick = { showInnerFilterDialog = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.FilterAlt, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        val incC = SmsHelper.parseKeywords(includeKeywords).size
                        val excC = SmsHelper.parseKeywords(excludeKeywords).size
                        Text(
                            if (incC == 0 && excC == 0) "إعداد تصفية الكلمات (اختياري)"
                            else "تصفية الكلمات ($incC إرسال / $excC منع)"
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "اختر أرقام المستلمين:",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))

                    recipients.forEach { rec ->
                        val checked = selectedRecipientIds.contains(rec.id)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (checked) selectedRecipientIds.remove(rec.id)
                                    else selectedRecipientIds.add(rec.id)
                                }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = checked,
                                onCheckedChange = { isChecked ->
                                    if (isChecked) {
                                        if (!selectedRecipientIds.contains(rec.id)) selectedRecipientIds.add(rec.id)
                                    } else {
                                        selectedRecipientIds.remove(rec.id)
                                    }
                                }
                            )
                            Column {
                                Text(
                                    text = rec.phoneNumber,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                if (rec.label.isNotBlank()) {
                                    Text(
                                        text = rec.label,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val bank = selectedBank ?: return@Button
                        val autoName = ruleName.ifBlank { "توجيه ${bank.displayName}" }
                        onSaveRule(
                            currentRule?.rule?.id ?: 0L,
                            autoName,
                            bank.id,
                            selectedRecipientIds.toList(),
                            includeKeywords,
                            excludeKeywords,
                            currentRule?.rule?.isEnabled ?: true
                        )
                        showRuleDialog = false
                    },
                    enabled = selectedBank != null && selectedRecipientIds.isNotEmpty()
                ) {
                    Text("حفظ")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRuleDialog = false }) {
                    Text("إلغاء")
                }
            }
        )

        if (showInnerFilterDialog) {
            KeywordFilterDialog(
                title = "تصفية كلمات القاعدة",
                subtitle = "تُمنع الرسالة إذا طابقت قائمة المنع، وتُرسل فقط إذا طابقت قائمة الإرسال (إن وُجدت).",
                initialInclude = includeKeywords,
                initialExclude = excludeKeywords,
                onDismiss = { showInnerFilterDialog = false },
                onSave = { inc, exc ->
                    includeKeywords = inc
                    excludeKeywords = exc
                    showInnerFilterDialog = false
                }
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun KeywordFilterDialog(
    title: String,
    subtitle: String,
    initialInclude: String,
    initialExclude: String,
    onDismiss: () -> Unit,
    onSave: (includeKeywords: String, excludeKeywords: String) -> Unit
) {
    val includeList = remember {
        mutableStateListOf<String>().apply {
            addAll(SmsHelper.parseKeywords(initialInclude))
        }
    }
    val excludeList = remember {
        mutableStateListOf<String>().apply {
            addAll(SmsHelper.parseKeywords(initialExclude))
        }
    }
    var includeInput by remember { mutableStateOf("") }
    var excludeInput by remember { mutableStateOf("") }

    val includeSuggestions = listOf("تم إيداع", "تم خصم", "حوالة", "إيداع", "سحب")
    val excludeSuggestions = listOf("رمز التأكيد", "رمز التحقق", "OTP", "كلمة المرور", "الرمز السري")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 480.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // قسم كلمات الإرسال
                Text(
                    text = "✅ كلمات الإرسال (أرسل إذا احتوت الرسالة على):",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF065F46)
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = includeInput,
                        onValueChange = { includeInput = it },
                        placeholder = { Text("مثال: تم إيداع") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Button(
                        onClick = {
                            val word = includeInput.trim()
                            if (word.isNotEmpty() && !includeList.contains(word)) {
                                includeList.add(word)
                            }
                            includeInput = ""
                        },
                        enabled = includeInput.isNotBlank()
                    ) {
                        Text("إضافة")
                    }
                }
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    includeSuggestions.filter { !includeList.contains(it) }.forEach { sug ->
                        SuggestionChip(
                            onClick = { includeList.add(sug) },
                            label = { Text("+ $sug", style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
                if (includeList.isNotEmpty()) {
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        includeList.forEach { word ->
                            InputChip(
                                selected = true,
                                onClick = { includeList.remove(word) },
                                label = { Text(word) },
                                trailingIcon = {
                                    Icon(
                                        Icons.Default.Close,
                                        contentDescription = "حذف",
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                colors = InputChipDefaults.inputChipColors(
                                    selectedContainerColor = Color(0xFFD1FAE5),
                                    selectedLabelColor = Color(0xFF065F46)
                                )
                            )
                        }
                    }
                }

                HorizontalDivider()

                // قسم كلمات المنع
                Text(
                    text = "🚫 كلمات المنع (لا ترسل إذا احتوت الرسالة على):",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF991B1B)
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = excludeInput,
                        onValueChange = { excludeInput = it },
                        placeholder = { Text("مثال: رمز التأكيد") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Button(
                        onClick = {
                            val word = excludeInput.trim()
                            if (word.isNotEmpty() && !excludeList.contains(word)) {
                                excludeList.add(word)
                            }
                            excludeInput = ""
                        },
                        enabled = excludeInput.isNotBlank()
                    ) {
                        Text("إضافة")
                    }
                }
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    excludeSuggestions.filter { !excludeList.contains(it) }.forEach { sug ->
                        SuggestionChip(
                            onClick = { excludeList.add(sug) },
                            label = { Text("+ $sug", style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
                if (excludeList.isNotEmpty()) {
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        excludeList.forEach { word ->
                            InputChip(
                                selected = true,
                                onClick = { excludeList.remove(word) },
                                label = { Text(word) },
                                trailingIcon = {
                                    Icon(
                                        Icons.Default.Close,
                                        contentDescription = "حذف",
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                colors = InputChipDefaults.inputChipColors(
                                    selectedContainerColor = Color(0xFFFEE2E2),
                                    selectedLabelColor = Color(0xFF991B1B)
                                )
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    // إضافة أي نص متبقٍ في حقول الإدخال قبل الحفظ
                    val finalInc = includeList.toMutableList()
                    if (includeInput.trim().isNotEmpty() && !finalInc.contains(includeInput.trim())) {
                        finalInc.add(includeInput.trim())
                    }
                    val finalExc = excludeList.toMutableList()
                    if (excludeInput.trim().isNotEmpty() && !finalExc.contains(excludeInput.trim())) {
                        finalExc.add(excludeInput.trim())
                    }
                    onSave(finalInc.joinToString(", "), finalExc.joinToString(", "))
                }
            ) {
                Text("حفظ الفلاتر")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}
