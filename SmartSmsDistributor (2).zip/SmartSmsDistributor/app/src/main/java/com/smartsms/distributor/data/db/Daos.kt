package com.smartsms.distributor.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface BankSenderDao {
    @Query("SELECT * FROM bank_senders ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<BankSenderEntity>>

    @Query("SELECT * FROM bank_senders WHERE isEnabled = 1")
    suspend fun getEnabledSenders(): List<BankSenderEntity>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(sender: BankSenderEntity): Long

    @Update
    suspend fun update(sender: BankSenderEntity)

    @Delete
    suspend fun delete(sender: BankSenderEntity)

    @Query("UPDATE bank_senders SET isEnabled = :enabled WHERE id = :id")
    suspend fun setEnabled(id: Long, enabled: Boolean)
}

@Dao
interface RecipientDao {
    @Query("SELECT * FROM recipients ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<RecipientEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(recipient: RecipientEntity): Long

    @Update
    suspend fun update(recipient: RecipientEntity)

    @Delete
    suspend fun delete(recipient: RecipientEntity)

    @Query("UPDATE recipients SET isEnabled = :enabled WHERE id = :id")
    suspend fun setEnabled(id: Long, enabled: Boolean)
}

@Dao
interface ForwardingRuleDao {
    @Transaction
    @Query("SELECT * FROM forwarding_rules ORDER BY createdAt DESC")
    fun observeAllWithDetails(): Flow<List<RuleWithDetails>>

    @Transaction
    @Query("SELECT * FROM forwarding_rules WHERE bankSenderId = :bankSenderId AND isEnabled = 1")
    suspend fun getEnabledRulesForBank(bankSenderId: Long): List<RuleWithDetails>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRule(rule: ForwardingRuleEntity): Long

    @Update
    suspend fun updateRule(rule: ForwardingRuleEntity)

    @Delete
    suspend fun deleteRule(rule: ForwardingRuleEntity)

    @Query("UPDATE forwarding_rules SET isEnabled = :enabled WHERE id = :id")
    suspend fun setEnabled(id: Long, enabled: Boolean)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertCrossRefs(refs: List<RuleRecipientCrossRef>)

    @Query("DELETE FROM rule_recipient_cross_ref WHERE ruleId = :ruleId")
    suspend fun deleteCrossRefsForRule(ruleId: Long)

    @Transaction
    suspend fun saveRuleWithRecipients(
        rule: ForwardingRuleEntity,
        recipientIds: List<Long>
    ): Long {
        val ruleId = if (rule.id == 0L) {
            insertRule(rule)
        } else {
            updateRule(rule)
            deleteCrossRefsForRule(rule.id)
            rule.id
        }
        val refs = recipientIds.distinct().map { recipientId ->
            RuleRecipientCrossRef(ruleId = ruleId, recipientId = recipientId)
        }
        if (refs.isNotEmpty()) {
            insertCrossRefs(refs)
        }
        return ruleId
    }
}

@Dao
interface TransferLogDao {
    @Query("SELECT * FROM transfer_logs ORDER BY receivedAt DESC")
    fun observeAll(): Flow<List<TransferLogEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM transfer_logs WHERE messageKey = :messageKey AND recipientNumber = :recipientNumber)")
    suspend fun existsByKeyAndRecipient(messageKey: String, recipientNumber: String): Boolean

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(log: TransferLogEntity): Long

    @Query("SELECT * FROM transfer_logs WHERE id = :id")
    suspend fun getById(id: Long): TransferLogEntity?

    @Query("UPDATE transfer_logs SET sentParts = sentParts + 1, status = CASE WHEN status != 'FAILED' AND status != 'DELIVERED' AND (sentParts + 1) >= totalParts THEN 'SENT' ELSE status END WHERE id = :id")
    suspend fun markPartSent(id: Long)

    @Query("UPDATE transfer_logs SET deliveredParts = deliveredParts + 1, status = CASE WHEN status != 'FAILED' AND (deliveredParts + 1) >= totalParts THEN 'DELIVERED' ELSE status END WHERE id = :id")
    suspend fun markPartDelivered(id: Long)

    @Query("UPDATE transfer_logs SET status = 'FAILED', errorMessage = :errorMessage WHERE id = :id")
    suspend fun markFailed(id: Long, errorMessage: String)

    @Query("DELETE FROM transfer_logs")
    suspend fun clearAll()
}
