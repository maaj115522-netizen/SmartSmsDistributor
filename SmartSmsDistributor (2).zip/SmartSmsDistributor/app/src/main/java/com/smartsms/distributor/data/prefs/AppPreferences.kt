package com.smartsms.distributor.data.prefs

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AppPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val _isServiceEnabled = MutableStateFlow(prefs.getBoolean(KEY_SERVICE_ENABLED, false))
    val isServiceEnabled: StateFlow<Boolean> = _isServiceEnabled.asStateFlow()

    private val _selectedSubscriptionId = MutableStateFlow(prefs.getInt(KEY_SIM_SUB_ID, DEFAULT_SIM_ID))
    val selectedSubscriptionId: StateFlow<Int> = _selectedSubscriptionId.asStateFlow()

    private val _globalIncludeKeywords = MutableStateFlow(prefs.getString(KEY_GLOBAL_INCLUDE, "").orEmpty())
    val globalIncludeKeywords: StateFlow<String> = _globalIncludeKeywords.asStateFlow()

    private val _globalExcludeKeywords = MutableStateFlow(prefs.getString(KEY_GLOBAL_EXCLUDE, "").orEmpty())
    val globalExcludeKeywords: StateFlow<String> = _globalExcludeKeywords.asStateFlow()

    fun setServiceEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_SERVICE_ENABLED, enabled).apply()
        _isServiceEnabled.value = enabled
    }

    fun isServiceEnabledSync(): Boolean = prefs.getBoolean(KEY_SERVICE_ENABLED, false)

    fun setSelectedSubscriptionId(subId: Int) {
        prefs.edit().putInt(KEY_SIM_SUB_ID, subId).apply()
        _selectedSubscriptionId.value = subId
    }

    fun getSelectedSubscriptionIdSync(): Int = prefs.getInt(KEY_SIM_SUB_ID, DEFAULT_SIM_ID)

    fun setGlobalFilters(includeKeywords: String, excludeKeywords: String) {
        prefs.edit()
            .putString(KEY_GLOBAL_INCLUDE, includeKeywords)
            .putString(KEY_GLOBAL_EXCLUDE, excludeKeywords)
            .apply()
        _globalIncludeKeywords.value = includeKeywords
        _globalExcludeKeywords.value = excludeKeywords
    }

    fun getGlobalIncludeKeywordsSync(): String = prefs.getString(KEY_GLOBAL_INCLUDE, "").orEmpty()

    fun getGlobalExcludeKeywordsSync(): String = prefs.getString(KEY_GLOBAL_EXCLUDE, "").orEmpty()

    companion object {
        private const val PREFS_NAME = "smart_sms_prefs"
        private const val KEY_SERVICE_ENABLED = "service_enabled"
        private const val KEY_SIM_SUB_ID = "selected_sim_subscription_id"
        private const val KEY_GLOBAL_INCLUDE = "global_include_keywords"
        private const val KEY_GLOBAL_EXCLUDE = "global_exclude_keywords"
        const val DEFAULT_SIM_ID = -1
    }
}
